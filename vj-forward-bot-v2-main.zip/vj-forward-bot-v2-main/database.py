# Don't Remove Credit Tg - @VJ_Botz
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

import motor.motor_asyncio
from config import Config

class Db:

    def __init__(self, uri, database_name):
        self._client = motor.motor_asyncio.AsyncIOMotorClient(uri)
        self.db = self._client[database_name]
        self.bot = self.db.bots
        self.userbot = self.db.userbot 
        self.col = self.db.users
        self.nfy = self.db.notify
        self.chl = self.db.channels 

    def new_user(self, id, name):
        return dict(
            id = id,
            name = name,
            ban_status=dict(
                is_banned=False,
                ban_reason="",
            ),
        )

    async def add_user(self, id, name):
        user = self.new_user(id, name)
        await self.col.insert_one(user)

    async def is_user_exist(self, id):
        user = await self.col.find_one({'id':int(id)})
        return bool(user)

    async def total_users_count(self):
        count = await self.col.count_documents({})
        return count

    async def total_users_bots_count(self):
        bcount = await self.bot.count_documents({})
        count = await self.col.count_documents({})
        return count, bcount

    async def remove_ban(self, id):
        ban_status = dict(is_banned=False, ban_reason='')
        await self.col.update_one({'id': id}, {'$set': {'ban_status': ban_status}})

    async def ban_user(self, user_id, ban_reason="No Reason"):
        ban_status = dict(is_banned=True, ban_reason=ban_reason)
        await self.col.update_one({'id': user_id}, {'$set': {'ban_status': ban_status}})

    async def get_ban_status(self, id):
        default = dict(is_banned=False, ban_reason='')
        user = await self.col.find_one({'id':int(id)})
        if not user:
            return default
        return user.get('ban_status', default)

    async def get_all_users(self):
        return self.col.find({})

    async def delete_user(self, user_id):
        await self.col.delete_many({'id': int(user_id)})

    async def get_banned(self):
        users = self.col.find({'ban_status.is_banned': True})
        b_users = [user['id'] async for user in users]
        return b_users

    async def update_configs(self, id, configs):
        await self.col.update_one({'id': int(id)}, {'$set': {'configs': configs}})

    async def get_configs(self, id):
        default = {
            'caption': None,
            'duplicate': True,
            'forward_tag': False,
            'min_size': 0,
            'max_size': 0,
            'extension': None,
            'keywords': None,
            'protect': None,
            'button': None,
            'db_uri': None,
            'filters': {
               'poll': True,
               'text': True,
               'audio': True,
               'voice': True,
               'video': True,
               'photo': True,
               'document': True,
               'animation': True,
               'sticker': True
            }
        }
        user = await self.col.find_one({'id':int(id)})
        if user:
            return user.get('configs', default)
        return default

    # ── Multi-bot support ──────────────────────────────────────────

    async def add_bot_to_list(self, user_id, bot_details):
        """Add a bot to user's bot list (supports multiple bots)."""
        user_data = await self.col.find_one({'id': int(user_id)})
        bots = user_data.get('bots', []) if user_data else []
        for b in bots:
            if b['id'] == bot_details['id']:
                return False  # already exists
        bots.append(bot_details)
        await self.col.update_one(
            {'id': int(user_id)},
            {'$set': {'bots': bots}},
            upsert=True
        )
        return True

    async def get_all_bots(self, user_id):
        """Get all bots for a user."""
        user_data = await self.col.find_one({'id': int(user_id)})
        if user_data and 'bots' in user_data:
            return user_data['bots']
        # Fallback: migrate from old single-bot collection
        old_bot = await self.bot.find_one({'user_id': int(user_id)})
        if old_bot:
            await self.add_bot_to_list(user_id, old_bot)
            return [old_bot]
        return []

    async def remove_bot_by_index(self, user_id, index):
        """Remove a bot by its index in the list."""
        user_data = await self.col.find_one({'id': int(user_id)})
        if not user_data or 'bots' not in user_data:
            return False
        bots = user_data['bots']
        if 0 <= index < len(bots):
            bots.pop(index)
            await self.col.update_one({'id': int(user_id)}, {'$set': {'bots': bots}})
            return True
        return False

    async def remove_bot_by_id(self, user_id, bot_id):
        """Remove a bot by its Telegram ID."""
        user_data = await self.col.find_one({'id': int(user_id)})
        if not user_data or 'bots' not in user_data:
            return False
        bots = [b for b in user_data['bots'] if b['id'] != bot_id]
        await self.col.update_one({'id': int(user_id)}, {'$set': {'bots': bots}})
        return True

    # ── Backward-compatible single-bot methods ─────────────────────

    async def add_bot(self, datas):
        """Add bot — backward compatible, delegates to add_bot_to_list."""
        return await self.add_bot_to_list(datas['user_id'], datas)

    async def remove_bot(self, user_id):
        """Remove ALL bots for a user."""
        await self.col.update_one({'id': int(user_id)}, {'$unset': {'bots': ''}})
        await self.bot.delete_many({'user_id': int(user_id)})

    async def get_bot(self, user_id: int):
        """Get first bot (backward compatible)."""
        bots = await self.get_all_bots(user_id)
        return bots[0] if bots else None

    async def is_bot_exist(self, user_id):
        bots = await self.get_all_bots(user_id)
        return len(bots) > 0

    # ── Userbot ────────────────────────────────────────────────────

    async def add_userbot(self, datas):
       if not await self.is_userbot_exist(datas['user_id']):
          await self.userbot.insert_one(datas)

    async def remove_userbot(self, user_id):
       await self.userbot.delete_many({'user_id': int(user_id)})

    async def get_userbot(self, user_id: int):
       bot = await self.userbot.find_one({'user_id': user_id})
       return bot if bot else None

    async def is_userbot_exist(self, user_id):
       bot = await self.userbot.find_one({'user_id': user_id})
       return bool(bot)

    # ── Channels ───────────────────────────────────────────────────

    async def in_channel(self, user_id: int, chat_id: int) -> bool:
       channel = await self.chl.find_one({"user_id": int(user_id), "chat_id": int(chat_id)})
       return bool(channel)

    async def add_channel(self, user_id: int, chat_id: int, title, username):
       channel = await self.in_channel(user_id, chat_id)
       if channel:
         return False
       return await self.chl.insert_one({"user_id": user_id, "chat_id": chat_id, "title": title, "username": username})

    async def remove_channel(self, user_id: int, chat_id: int):
       channel = await self.in_channel(user_id, chat_id)
       if not channel:
         return False
       return await self.chl.delete_many({"user_id": int(user_id), "chat_id": int(chat_id)})

    async def get_channel_details(self, user_id: int, chat_id: int):
       return await self.chl.find_one({"user_id": int(user_id), "chat_id": int(chat_id)})

    async def get_user_channels(self, user_id: int):
       channels = self.chl.find({"user_id": int(user_id)})
       return [channel async for channel in channels]

    async def get_filters(self, user_id):
       filters = []
       filter = (await self.get_configs(user_id))['filters']
       for k, v in filter.items():
          if v == False:
            filters.append(str(k))
       return filters

    # ── Forward tracking ───────────────────────────────────────────

    async def add_frwd(self, user_id):
       return await self.nfy.insert_one({'user_id': int(user_id)})

    async def rmve_frwd(self, user_id=0, all=False):
       data = {} if all else {'user_id': int(user_id)}
       return await self.nfy.delete_many(data)

    async def get_all_frwd(self):
       return self.nfy.find({})

    async def forwad_count(self):
        c = await self.nfy.count_documents({})
        return c

    async def is_forwad_exit(self, user):
        u = await self.nfy.find_one({'user_id': user})
        return bool(u)

    async def get_forward_details(self, user_id):
        defult = {
            'chat_id': None,
            'forward_id': None,
            'toid': None,
            'last_id': None,
            'limit': None,
            'msg_id': None,
            'start_time': None,
            'fetched': 0,
            'offset': 0,
            'deleted': 0,
            'total': 0,
            'duplicate': 0,
            'skip': 0,
            'filtered': 0
        }
        user = await self.nfy.find_one({'user_id': int(user_id)})
        if user:
            return user.get('details', defult)
        return defult

    async def update_forward(self, user_id, details):
        await self.nfy.update_one({'user_id': user_id}, {'$set': {'details': details}})

    # ── Batch speed settings ───────────────────────────────────────────────

    async def get_batch_settings(self, user_id):
        default = {
            'batch_size': 20,
            'base_sleep': 3.0,
            'stagger_delay': 0.2,
        }
        user = await self.col.find_one({'id': int(user_id)})
        if user:
            return user.get('batch_settings', default)
        return default

    async def update_batch_settings(self, user_id, key, value):
        settings = await self.get_batch_settings(user_id)
        settings[key] = value
        await self.col.update_one(
            {'id': int(user_id)},
            {'$set': {'batch_settings': settings}},
            upsert=True
        )

db = Db(Config.DATABASE_URI, Config.DATABASE_NAME)
